import React from 'react'
import TextImageInterface from './text_image.interface'
import styles from './text_image.module.scss'

export const typename = 'Set_Replicator_BlockTextImage'

const TextImageBlock = ({ block }: { block: TextImageInterface }) => (
  <div
    className={styles.root}
  >
    Text Image Block:
    {block.headline}
  </div>
)

export default TextImageBlock
