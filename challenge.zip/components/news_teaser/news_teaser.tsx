import React from 'react'
import styles from './news_teaser.module.scss'
import NewsTeaserInterface from './news_teaser.interface'

export const typename = 'Set_Replicator_BlockNewsTeaser'

const NewsTeaserBlock = ({ block }: { block: NewsTeaserInterface }) => (
  <div
    className={styles.root}
  >
    Newsteaser Block:
    {block.description}
  </div>
)

export default NewsTeaserBlock
