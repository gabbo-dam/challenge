This is a [Next.js](https://nextjs.org/) + Statamic project boilerplate made by PXLP.

## Getting Started

1. Copy the .env.local.example to .env.local
2. run the development server:

```bash
yarn dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

You can now start building your components in the components folder, all component files have already been added.

For all assets imgix is available
https://challenge-pxlp-assets.imgix.net
