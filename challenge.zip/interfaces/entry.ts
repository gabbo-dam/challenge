export default interface Entry {
  id: string | number,
  replicator: any[],
}
